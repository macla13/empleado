<template>
    <div> 

        Actualizar proyecto
    </div>
</template>
<script>
export default {
    
}
</script>