<template>
    <div class="container"> 

      <div class="card">
          <div class="card-header">
              Agregar nuevo Empleado
          </div>
          <div class="card-body">
             
             <form v-on:submit.prevent="AgregarEmpleado">
                 <div class="form-group">
                   <label for="Primer_Nombre">Primer Nombre:</label>
                   <input type="text"
                     class="form-control" required name="Primer_Nombre" v-model="empleado.Primer_Nombre" id="Primer_Nombre" aria-describedby="helpId" placeholder="Primer Nombre">
                   <small id="helpId" class="form-text text-muted">Digite el primer nombre del empleado</small>
                 </div>

                    <div class="form-group">
                <label for="correoElectronico">correo Electronico:</label>
                      <input type="email"
                        class="form-control" required name="correoElectronico"  v-model="empleado.correoElectronico" id="correoElectronico" aria-describedby="helpId" placeholder="correo Electronico">
                      <small id="helpId" class="form-text text-muted">Digite el correo electronico</small>
                    </div>

                    <div class="form-group">
                      <label for="Telefono_Personal">Telefono Personal:</label>
                      <input type="text"
                        class="form-control" required name="Telefono_Personal"  v-model="empleado.Telefono_Personal" id="Telefono_Personal" aria-describedby="helpId" placeholder="Telefono Personal">
                      <small id="helpId" class="form-text text-muted">Digite el telefono personal</small>
                    </div>

                    <div class="btn-group" role="group" aria-label="">
                        <button type="submit" class="btn btn-success">Agregar</button>
                        <router-link: to = "{name:'listar'}" class = "btn btn-warning"> Cancelar </router-link:>
                        
                    </div>
             </form>


          </div>
          
      </div>
    </div>
</template>
<script>
export default {
       
       data(){
               
               return{

                   empleado:{}
               }
       },
       methods:{

           AgregarEmpleado(){

               console.log(this.empleado);

               var datosEnvia = {PrimerNombre:this.empleado.Primer_Nombre, correoElectronico:this.empleado.correoElectronico,TelefonoPersonal:this.empleado.Telefono_Personal}
               
                console.log(datosEnvia)

               fetch('http://localhost/empleados/?insertar=1',{

                      method:"POST",
                      "body":(datosEnvia)
                     
                })
                 .then(respuesta=>respuesta.json())
                 .then((datosRespuesta=> {
                 
                     console.log(datosRespuesta)

                     window.location.href='listar'

                 })).catch(err=>console.log(err))

           },
          
       }



}
</script>