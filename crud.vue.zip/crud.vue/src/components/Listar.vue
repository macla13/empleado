<template>
    <div class ="container">

        <div class="card">
            <div class="card-header">
                Empleados
            </div>
            <div class="card-body">
                
                    <table class="table">
                        <thead>
                            <tr>
                                <th>idEmpleado</th>
                                <th>Primer_Nombre</th>
                                <th>correoElectronico</th>
                                <th>Telefono_Personal</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>

                            <tr v-for="empleado in empleados" :key="empleado.id">
                                <td>{{empleado.idEmpleado}}</td>
                                <td>{{empleado.Primer_Nombre}}</td>
                                <td>{{empleado.correoElectronico}}</td>
                                <td>{{empleado.Telefono_Personal}}</td>
                                <td>

                                    <div class="btn-group" role="group" aria-label="">
                                        

                                <router-link: to="{name: 'Editar',param:{id:empleado.id} } " class="btn btn-info">Editar<router-link>


                             <button type="button" v-on:click ="borrarEmpleado(empleado.id)" class="btn btn-danger">Borrar</button>
                                     
                                    </div>
              
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>

            </div>
           
        </div>

    </div>
</template>
<script>
export default {

    data(){
          
          return{

            empleados:[]
          }


    },

    created:function(){
              
              this.consultaEmpleado();
                 
    },
    methods:{
        //
        consultaEmpleado(){
            fetch('http://localhost/empleados/')
            .then(respuesta=>respuesta.json())
            .then((datosRespuesta)=>{

                console.log(datosRespuesta)
                this.empleados=[]

            if(typeof datosRespuesta[0].success=== 'undefined')
            {
                this.empleados= datosRespuesta;
            }
        
            })
            .catch(console.log)
            
    },

    BorrarEmpleado(id){

        console.log(id);

             fetch('http://localhost/empleados/?borrar' +id)
            .then(respuesta=>respuesta.json())
            .then((datosRespuesta)=>{

                console.log(datosRespuesta)
               
                  window.location.href = 'listar'

            })
            .catch(console.log)
    }
}
 }
</script>